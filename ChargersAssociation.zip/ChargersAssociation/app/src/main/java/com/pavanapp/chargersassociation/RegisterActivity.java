package com.pavanapp.chargersassociation;

import android.app.Activity;

public class RegisterActivity extends Activity {
}
