package com.pavanapp.chargersassociation

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Login_Activity() : AppCompatActivity() {

    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText
    lateinit var btnLogin: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView
    val validMobileNumber = "0123456789"
    val validPassword = arrayOf("pavan", "chargers", "kalyan")
    lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        val isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)
        setContentView(R.layout.activity_login)
        if(isLoggedIn){
            val intent=Intent(this@Login_Activity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }


        title = "Log In"
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassowrd)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)


        btnLogin.setOnClickListener {
            val mobilenumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()
            var nameOfPerson = "Charger"
            val intent = Intent(this@Login_Activity, MainActivity::class.java)
            if (mobilenumber == validMobileNumber) {
                when(password) {
                validPassword[0] -> {
                    nameOfPerson = "Pavan"
                    savePreferences(nameOfPerson)
                    startActivity(intent)
                }
                    validPassword[1] -> {
                    nameOfPerson = "The Chargers Team"
                        savePreferences(nameOfPerson)
                    startActivity(intent)
                }
                    validPassword[2] -> {
                    nameOfPerson = "Kalyan"
                        savePreferences(nameOfPerson)
                    startActivity(intent)
                }
                    else -> Toast.makeText(this@Login_Activity, "Incorrect Number/Password", Toast.LENGTH_LONG)
                        .show()

            }
            }

        }


    }

    override fun onPause() {
        super.onPause()
        finish()
    }
    fun savePreferences (title:String){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("Title", title).apply()
    }

}





