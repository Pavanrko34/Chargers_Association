package com.pavanapp.atomapp

interface Windows {

}
